from Bot import Bot


def main():

    html_link = "https://www.minecraftcrafting.info/"

    chatbot = Bot(html_link)
    chatbot.run()

    return 0


main()
